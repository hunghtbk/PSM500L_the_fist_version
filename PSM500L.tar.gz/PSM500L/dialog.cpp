#include "qextserialport.h"
#include "qextserialenumerator.h"
#include "dialog.h"
#include "ui_dialog.h"
#include <QtCore>
#include "function_Check.h"
Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    //! [0]
    foreach (QextPortInfo info, QextSerialEnumerator::getPorts())
        ui->portBox1->addItem(info.portName);
    //make sure user can input their own port name!
    ui->portBox1->setEditable(true);

    ui->baudRateBox1->addItem("1200", BAUD1200);
    ui->baudRateBox1->addItem("2400", BAUD2400);
    ui->baudRateBox1->addItem("4800", BAUD4800);
    ui->baudRateBox1->addItem("9600", BAUD9600);
    ui->baudRateBox1->addItem("19200", BAUD19200);
    ui->baudRateBox1->addItem("38400", BAUD38400);
    ui->baudRateBox1->setCurrentIndex(3);

    ui->parityBox1->addItem("NONE", PAR_NONE);
    ui->parityBox1->addItem("ODD", PAR_ODD);
    ui->parityBox1->addItem("EVEN", PAR_EVEN);

    ui->dataBitsBox1->addItem("5", DATA_5);
    ui->dataBitsBox1->addItem("6", DATA_6);
    ui->dataBitsBox1->addItem("7", DATA_7);
    ui->dataBitsBox1->addItem("8", DATA_8);
    ui->dataBitsBox1->setCurrentIndex(3);

    ui->stopBitsBox1->addItem("1", STOP_1);
    ui->stopBitsBox1->addItem("2", STOP_2);

    ui->queryModeBox1->addItem("Polling", QextSerialPort::Polling);
    ui->queryModeBox1->addItem("EventDriven", QextSerialPort::EventDriven);
    //! [0]

    ui->led1->turnOff();

    timer = new QTimer(this);
    timer->setInterval(40);
    //! [1]
    PortSettings settings = {BAUD9600, DATA_8, PAR_NONE, STOP_1, FLOW_OFF, 10};
    port = new QextSerialPort(ui->portBox1->currentText(), settings, QextSerialPort::Polling);
    //! [1]

    enumerator = new QextSerialEnumerator(this);
    enumerator->setUpNotifications();

    connect(ui->baudRateBox1, SIGNAL(currentIndexChanged(int)), SLOT(onBaudRateChanged(int)));
    //connect(ui->cmbModulation1, SIGNAL(currentIndexChanged(int)), SLOT(onModulation1(int)));
    //connect(ui->cmbModulation2, SIGNAL(currentIndexChanged(int)), SLOT(onModulation2(int)));
    connect(ui->parityBox1, SIGNAL(currentIndexChanged(int)), SLOT(onParityChanged(int)));
    connect(ui->dataBitsBox1, SIGNAL(currentIndexChanged(int)), SLOT(onDataBitsChanged(int)));
    connect(ui->stopBitsBox1, SIGNAL(currentIndexChanged(int)), SLOT(onStopBitsChanged(int)));
    connect(ui->queryModeBox1, SIGNAL(currentIndexChanged(int)), SLOT(onQueryModeChanged(int)));
    connect(ui->timeoutBox1, SIGNAL(valueChanged(int)), SLOT(onTimeoutChanged(int)));
    connect(ui->portBox1, SIGNAL(editTextChanged(QString)), SLOT(onPortNameChanged(QString)));
    connect(ui->openCloseButton1, SIGNAL(clicked()), SLOT(onOpenCloseButtonClicked()));
    connect(ui->sendButton1, SIGNAL(clicked()), SLOT(onSendButtonClicked()));
    connect(timer, SIGNAL(timeout()), SLOT(onReadyRead()));
    connect(port, SIGNAL(readyRead()), SLOT(onReadyRead()));

    connect(enumerator, SIGNAL(deviceDiscovered(QextPortInfo)), SLOT(onPortAddedOrRemoved()));
    connect(enumerator, SIGNAL(deviceRemoved(QextPortInfo)), SLOT(onPortAddedOrRemoved()));

    setWindowTitle(tr("Embedded Networking Research Group Lab 411"));


}

Dialog::~Dialog()
{
    delete ui;
    delete port;
}

void Dialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void Dialog::onPortNameChanged(const QString & /*name*/)
{
    if (port->isOpen()) {
        port->close();
        ui->led1->turnOff();
    }
}
//! [2]
void Dialog::onBaudRateChanged(int idx)
{
    port->setBaudRate((BaudRateType)ui->baudRateBox1->itemData(idx).toInt());
}

void Dialog::onParityChanged(int idx)
{
    port->setParity((ParityType)ui->parityBox1->itemData(idx).toInt());
}

void Dialog::onDataBitsChanged(int idx)
{
    port->setDataBits((DataBitsType)ui->dataBitsBox1->itemData(idx).toInt());
}

void Dialog::onStopBitsChanged(int idx)
{
    port->setStopBits((StopBitsType)ui->stopBitsBox1->itemData(idx).toInt());
}

void Dialog::onQueryModeChanged(int idx)
{
    port->setQueryMode((QextSerialPort::QueryMode)ui->queryModeBox1->itemData(idx).toInt());
}

void Dialog::onTimeoutChanged(int val)
{
    port->setTimeout(val);
}
//! [2]
//! [3]
void Dialog::onOpenCloseButtonClicked()
{
    if (!port->isOpen()) {
        port->setPortName(ui->portBox1->currentText());
        port->open(QIODevice::ReadWrite);
    }
    else {
        port->close();
    }

    //If using polling mode, we need a QTimer
    if (port->isOpen() && port->queryMode() == QextSerialPort::Polling)
        timer->start();
    else
        timer->stop();

    //update led's status
    ui->led1->turnOn(port->isOpen());
}
//! [3]
//! [4]
void Dialog::onSendButtonClicked()
{

    if (port->isOpen() && !ui->sendEdit1->toPlainText().isEmpty())
        port->write(ui->sendEdit1->toPlainText().toLatin1());
        ui->sendEdit1->clear();
}

void Dialog::onReadyRead()
{
    if (port->bytesAvailable()) {
        ui->recvEdit1->moveCursor(QTextCursor::End);
        ui->recvEdit1->insertPlainText(QString::fromLatin1(port->readAll()));
        qDebug()<<"Debug :---->"<<(QString::fromLatin1(port->readAll()));


    }
}

void Dialog::onModulation1(int idx)
{

}

void Dialog::onModulation2(int idx)
{

}

void Dialog::onPortAddedOrRemoved()
{
    QString current = ui->portBox1->currentText();

    ui->portBox1->blockSignals(true);
    ui->portBox1->clear();
    foreach (QextPortInfo info, QextSerialEnumerator::getPorts())
        ui->portBox1->addItem(info.portName);

    ui->portBox1->setCurrentIndex(ui->portBox1->findText(current));

    ui->portBox1->blockSignals(false);
}

//! [4]

void Dialog::on_pushButton_clicked()
{
    qApp->quit();
}



void Dialog::on_pushButton_2_clicked()
{
    QString a=ui->lineEdit1->text();a=a+"\n";

    qDebug()<<a;

    QByteArray ba = a.toLatin1();
    const char *c_str2 = ba.data();
    port->write(c_str2);
    ui->label_name->setText("PassWord");
    ui->lineEdit1->setText("datum");
}

void Dialog::on_pushButton_5_clicked()
{
    //day la nut ser dr
   /* QString LENH;
    QString x=ui->lneDataRate1->text();
    int _cmd2=CheckcmbModulation_2(ui->cmbModulation2->currentText());
    if(_cmd2==1){
        LENH="mq mdr "+x+"\n";
    }
    else if(_cmd2==2){
        LENH="mq ddr "+x+"\n";
    }

    QByteArray ba = LENH.toLatin1();
    const char *c_str2 = ba.data();
    port->write(c_str2);
    //qDebug()<<LENH;*/
}

void Dialog::on_btnSet1_clicked()
{
   /* //day la nut set
    QString x=ui->lneDataRate1->text();
    QString LENH,Lenh1;
    int _cmd1=CheckcmbModulation_1(ui->cmbModulation1->currentText());
    int _cmd2=CheckcmbModulation_2(ui->cmbModulation2->currentText());
    if(_cmd2==1){
        Lenh1="mq mdr "+x+"\n";
        QByteArray _ba = Lenh1.toLatin1();
        const char *c_str2_ = _ba.data();
        port->write(c_str2_);
        qDebug()<<Lenh1;
        switch(_cmd1){
        case 0: LENH="m500ctl 0 mdm 0\n";break;
        case 1: LENH="m500ctl 0 mdm 1\n";break;
        case 2: LENH="m500ctl 0 mdm 2\n";break;
        case 3: LENH="m500ctl 0 mdm 3\n";break;
        case 4: LENH="m500ctl 0 mdm 4\n";break;
        case 6: LENH="m500ctl 0 mdm 6\n";break;
        default: break;
        }
    }
    else if(_cmd2==2){

        Lenh1="mq ddr "+x+"\n";
        QByteArray _ba = Lenh1.toLatin1();
        const char *c_str2_ = _ba.data();
        port->write(c_str2_);
        qDebug()<<Lenh1;

        switch(_cmd1){
        case 0: LENH="m500ctl 0 ddm 0\n";break;
        case 1: LENH="m500ctl 0 ddm 1\n";break;
        case 2: LENH="m500ctl 0 ddm 2\n";break;
        case 3: LENH="m500ctl 0 ddm 3\n";break;
        case 4: LENH="m500ctl 0 ddm 4\n";break;
        case 6: LENH="m500ctl 0 ddm 6\n";break;
        default: break;
        }
    }
   // ui->sendEdit->document()->setPlainText(LENH);
      QByteArray ba = LENH.toLatin1();
      const char *c_str2 = ba.data();
    port->write(c_str2);
    qDebug()<<LENH;*/
}


/*void Dialog::on_comboBox_Mod_FECO_activated(const QString &arg1)
{
    int ___check;
    ___check=Check_FEC_Type(ui->comboBox_Mod_FECT->currentText());
    if(___check==0){
        ui->comboBox_Mod_FECO->addItem("None");
    }
}*/

void Dialog::on_comboBox_Mod_FECT_currentIndexChanged(const QString &arg1)
{
    QString a=ui->comboBox_Mod_FECT->currentText();

    if(a=="UnCoded"){
        while(ui->comboBox_Mod_FECO->count()>0){
            ui->comboBox_Mod_FECO->removeItem(0);
        }
    ui->comboBox_Mod_FECO->addItem("None");
   }
    else if(a=="Viterbi"){
        while(ui->comboBox_Mod_FECO->count()>0){
            ui->comboBox_Mod_FECO->removeItem(0);
        }
        ui->comboBox_Mod_FECO->addItem("Normal");
        ui->comboBox_Mod_FECO->addItem("Swap C0/C1");
        ui->comboBox_Mod_FECO->addItem("CT");
    }
    else if(a=="TCM"){
        while(ui->comboBox_Mod_FECO->count()>0){
            ui->comboBox_Mod_FECO->removeItem(0);
        }

        ui->comboBox_Mod_FECO->addItem("Normal");
    }
    else if(a=="TPC"){
        while(ui->comboBox_Mod_FECO->count()>0){
            ui->comboBox_Mod_FECO->removeItem(0);
        }

        ui->comboBox_Mod_FECO->addItem("Advanced");
        ui->comboBox_Mod_FECO->addItem("M5 Full");
        ui->comboBox_Mod_FECO->addItem("M5 Short");
        ui->comboBox_Mod_FECO->addItem("M5 Legacy");
        ui->comboBox_Mod_FECO->addItem("CT");
    }
    else if(a=="LDPC"){
        while(ui->comboBox_Mod_FECO->count()>0){
            ui->comboBox_Mod_FECO->removeItem(0);
        }

        ui->comboBox_Mod_FECO->addItem("256 Block");
        ui->comboBox_Mod_FECO->addItem("512 Block");
        ui->comboBox_Mod_FECO->addItem("1K Block");
        ui->comboBox_Mod_FECO->addItem("2K Block");
        ui->comboBox_Mod_FECO->addItem("4K Block");
        ui->comboBox_Mod_FECO->addItem("8K Block");
        ui->comboBox_Mod_FECO->addItem("16K Block");

    }
    else if(a=="S-Tec"){
        while(ui->comboBox_Mod_FECO->count()>0){
            ui->comboBox_Mod_FECO->removeItem(0);
        }

        ui->comboBox_Mod_FECO->addItem("Large");
        ui->comboBox_Mod_FECO->addItem("Medium");
        ui->comboBox_Mod_FECO->addItem("Small");
        ui->comboBox_Mod_FECO->addItem("XLarge");
    }
    qDebug()<<a;
}

void Dialog::on_pushButton_3_clicked()
{
    //Set Mod
   /*Set Data Rate*/
    QString LENH1;
    QString _cmd1=ui->lineEdit_Mod_DR->text();
    LENH1="mq mdr "+_cmd1+"\n";
    QByteArray ba1 = LENH1.toLatin1();
    const char *c_str1 = ba1.data();
    port->write(c_str1);

    /*Set Modulation Mode*/
    QString LENH2;
    int _intcmd=CheckcmbModulation_1(ui->comboBox_Mod_MM->currentText());
    switch(_intcmd){
    case 0: LENH2="m500ctl 0 mdm 0\n";break;
    case 1: LENH2="m500ctl 0 mdm 1\n";break;
    case 2: LENH2="m500ctl 0 mdm 2\n";break;
    case 3: LENH2="m500ctl 0 mdm 3\n";break;
    case 4: LENH2="m500ctl 0 mdm 4\n";break;
    case 6: LENH2="m500ctl 0 mdm 6\n";break;
    default: break;
    }
    QByteArray ba2=LENH2.toLatin1();
    const char *c_str2=ba2.data();
    port->write(c_str2);

    /*Set FEC Type*/

    QString LENH3;

    int _cmd3=Check_FEC_Type(ui->comboBox_Mod_FECT->currentText());
    switch(_cmd3){
        case 0: LENH3="m500ctl 0 mdf 0\n";break;
        case 1: LENH3="m500ctl 0 mdf 1\n";break;
        case 2: LENH3="m500ctl 0 mdf 2\n";break;
        case 4: LENH3="m500ctl 0 mdf 4\n";break;
        case 5: LENH3="m500ctl 0 mdf 5\n";break;
        case 6: LENH3="m500ctl 0 mdf 6\n";break;
    }
    QByteArray ba3=LENH3.toLatin1();
    const char *c_str3=ba3.data();
    port->write(c_str3);

    /*set FEC Option*/

    QString LENH4;

    int _cmd4=Check_FEC_Option(ui->comboBox_Mod_FECO->currentText());
    switch(_cmd4){
        case 0: LENH4="m500ctl 0 mdo 0\n";break;
        case 1: LENH4="m500ctl 0 mdo 1\n";break;
        case 2: LENH4="m500ctl 0 mdo 2\n";break;
        case 3: LENH4="m500ctl 0 mdo 3\n";break;
        case 4: LENH4="m500ctl 0 mdo 4\n";break;
        case 5: LENH4="m500ctl 0 mdo 5\n";break;
        case 6: LENH4="m500ctl 0 mdo 6\n";break;
    }
    QByteArray ba4=LENH4.toLatin1();
    const char *c_str4=ba4.data();
    port->write(c_str4);

    /*set FEC rate*/
    QString LENH5;
    int _cmd5=Check_FEC_Rate(ui->comboBox_Mod_FECR->currentText(),ui->comboBox_Mod_FECT->currentText(),ui->comboBox_Mod_FECO->currentText());
    switch (_cmd5) {
    case 0: LENH5="m500ctl 0 mdc 0\n";break;
    case 1: LENH5="m500ctl 0 mdc 1\n";break;
    case 2: LENH5="m500ctl 0 mdc 2\n";break;
    case 3: LENH5="m500ctl 0 mdc 3\n";break;
    case 4: LENH5="m500ctl 0 mdc 4\n";break;
    case 5: LENH5="m500ctl 0 mdc 5\n";break;
    case 6: LENH5="m500ctl 0 mdc 6\n";break;
    case 7: LENH5="m500ctl 0 mdc 7\n";break;
    case 8: LENH5="m500ctl 0 mdc 8\n";break;
    }
    QByteArray ba5=LENH5.toLatin1();
    const char *c_str5=ba5.data();
    port->write(c_str5);
}


void Dialog::on_pushButton_4_clicked()
{
    //Set DeMod


}

void Dialog::on_comboBox_Mod_FECO_currentIndexChanged(const QString &arg1)
{
    QString a=ui->comboBox_Mod_FECT->currentText();
    QString b=ui->comboBox_Mod_FECO->currentText();
    if(a=="UnCoded"){
        while(ui->comboBox_Mod_FECR->count()>0){
            ui->comboBox_Mod_FECR->removeItem(0);
        }
        if(b=="None")
        ui->comboBox_Mod_FECR->addItem("N/A");
   }
    else if(a=="Viterbi"){
        while(ui->comboBox_Mod_FECR->count()>0){
            ui->comboBox_Mod_FECR->removeItem(0);
        }
        if(b=="Normal"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("5/6");
            ui->comboBox_Mod_FECR->addItem("7/8");
        }
        else if(b=="Swap C0/C1"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("5/6");
            ui->comboBox_Mod_FECR->addItem("7/8");}
        else if(b=="CT"){
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("7/8");
            }

   }
    else if(a=="TCM"){
        while(ui->comboBox_Mod_FECR->count()>0){
            ui->comboBox_Mod_FECR->removeItem(0);
        }
        if(b=="Normal"){
            ui->comboBox_Mod_FECR->addItem("2/3");

        }
   }
    else if(a=="TPC"){
        while(ui->comboBox_Mod_FECR->count()>0){
            ui->comboBox_Mod_FECR->removeItem(0);
        }
        if(b=="Advanced"){
            ui->comboBox_Mod_FECR->addItem("0.453-16K");
            ui->comboBox_Mod_FECR->addItem("1/2-16K");
            ui->comboBox_Mod_FECR->addItem("1/2-4K");
            ui->comboBox_Mod_FECR->addItem("3/4-16K");
            ui->comboBox_Mod_FECR->addItem("3/4-4K");
            ui->comboBox_Mod_FECR->addItem("7/8-16K");
            ui->comboBox_Mod_FECR->addItem("7/8-4K");
            ui->comboBox_Mod_FECR->addItem("0.922-16K");
            ui->comboBox_Mod_FECR->addItem("0.950-4K");
        }
        else if(b=="M5 Full"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("7/8");
        }
        else if(b=="M5 Short"){
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("7/8");
        }
        else if(b=="M5 Legacy"){
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("7/8");
        }
        else if(b=="CT"){
            ui->comboBox_Mod_FECR->addItem("5/16");
            ui->comboBox_Mod_FECR->addItem("21/44");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("7/8");
            ui->comboBox_Mod_FECR->addItem("0.95");
        }
   }
    else if(a=="LDPC"){
        while(ui->comboBox_Mod_FECR->count()>0){
            ui->comboBox_Mod_FECR->removeItem(0);
        }
        if(b=="256 Block"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("2/3");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("14/17");
            ui->comboBox_Mod_FECR->addItem("7/8");
            ui->comboBox_Mod_FECR->addItem("10/11");
            ui->comboBox_Mod_FECR->addItem("16/17");
        }
        else if(b=="512 Block"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("2/3");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("14/17");
            ui->comboBox_Mod_FECR->addItem("7/8");
            ui->comboBox_Mod_FECR->addItem("10/11");
            ui->comboBox_Mod_FECR->addItem("16/17");
        }
        else if(b=="1K Block"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("2/3");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("14/17");
            ui->comboBox_Mod_FECR->addItem("7/8");
            ui->comboBox_Mod_FECR->addItem("10/11");
            ui->comboBox_Mod_FECR->addItem("16/17");
        }
        else if(b=="2K Block"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("2/3");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("14/17");
            ui->comboBox_Mod_FECR->addItem("7/8");
            ui->comboBox_Mod_FECR->addItem("10/11");
            ui->comboBox_Mod_FECR->addItem("16/17");
        }
        else if(b=="4K Block"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("2/3");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("14/17");
            ui->comboBox_Mod_FECR->addItem("7/8");
            ui->comboBox_Mod_FECR->addItem("10/11");
            ui->comboBox_Mod_FECR->addItem("16/17");
        }
        else if(b=="8K Block"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("2/3");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("14/17");
            ui->comboBox_Mod_FECR->addItem("7/8");
            ui->comboBox_Mod_FECR->addItem("10/11");
            ui->comboBox_Mod_FECR->addItem("16/17");
        }
        else if(b=="16K Block"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("2/3");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("14/17");
            ui->comboBox_Mod_FECR->addItem("7/8");
            ui->comboBox_Mod_FECR->addItem("10/11");
            ui->comboBox_Mod_FECR->addItem("16/17");
        }
    }
    else if(a=="S-Tec"){
        while(ui->comboBox_Mod_FECR->count()>0){
            ui->comboBox_Mod_FECR->removeItem(0);}
        if(b=="Large"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("3/5");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("4/5");
            ui->comboBox_Mod_FECR->addItem("5/6");
            ui->comboBox_Mod_FECR->addItem("7/8");
        }
        else if(b=="Medium"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("3/5");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("4/5");
            ui->comboBox_Mod_FECR->addItem("5/6");
            ui->comboBox_Mod_FECR->addItem("7/8");
        }
        else if(b=="Small"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("3/5");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("4/5");
            ui->comboBox_Mod_FECR->addItem("5/6");
            ui->comboBox_Mod_FECR->addItem("7/8");
        }
        else if(b=="XLarge"){
            ui->comboBox_Mod_FECR->addItem("1/2");
            ui->comboBox_Mod_FECR->addItem("3/5");
            ui->comboBox_Mod_FECR->addItem("3/4");
            ui->comboBox_Mod_FECR->addItem("4/5");
            ui->comboBox_Mod_FECR->addItem("5/6");
            ui->comboBox_Mod_FECR->addItem("7/8");
        }
    }
}

void Dialog::on_comboBox_DeMod_FECT_currentIndexChanged(const QString &arg1)
{
    QString a=ui->comboBox_DeMod_FECT->currentText();

    if(a=="UnCoded"){
        while(ui->comboBox_DeMod_FECO->count()>0){
            ui->comboBox_DeMod_FECO->removeItem(0);
        }
    ui->comboBox_DeMod_FECO->addItem("None");
   }
    else if(a=="Viterbi"){
        while(ui->comboBox_DeMod_FECO->count()>0){
            ui->comboBox_DeMod_FECO->removeItem(0);
        }
        ui->comboBox_DeMod_FECO->addItem("Normal");
        ui->comboBox_DeMod_FECO->addItem("Swap C0/C1");
        ui->comboBox_DeMod_FECO->addItem("CT");
    }
    else if(a=="TCM"){
        while(ui->comboBox_DeMod_FECO->count()>0){
            ui->comboBox_DeMod_FECO->removeItem(0);
        }

        ui->comboBox_DeMod_FECO->addItem("Normal");
    }
    else if(a=="TPC"){
        while(ui->comboBox_DeMod_FECO->count()>0){
            ui->comboBox_DeMod_FECO->removeItem(0);
        }

        ui->comboBox_DeMod_FECO->addItem("Advanced");
        ui->comboBox_DeMod_FECO->addItem("M5 Full");
        ui->comboBox_DeMod_FECO->addItem("M5 Short");
        ui->comboBox_DeMod_FECO->addItem("M5 Legacy");
        ui->comboBox_DeMod_FECO->addItem("CT");
    }
    else if(a=="LDPC"){
        while(ui->comboBox_DeMod_FECO->count()>0){
            ui->comboBox_DeMod_FECO->removeItem(0);
        }

        ui->comboBox_DeMod_FECO->addItem("256 Block");
        ui->comboBox_DeMod_FECO->addItem("512 Block");
        ui->comboBox_DeMod_FECO->addItem("1K Block");
        ui->comboBox_DeMod_FECO->addItem("2K Block");
        ui->comboBox_DeMod_FECO->addItem("4K Block");
        ui->comboBox_DeMod_FECO->addItem("8K Block");
        ui->comboBox_DeMod_FECO->addItem("16K Block");

    }
    else if(a=="S-Tec"){
        while(ui->comboBox_DeMod_FECO->count()>0){
            ui->comboBox_DeMod_FECO->removeItem(0);
        }

        ui->comboBox_DeMod_FECO->addItem("Large");
        ui->comboBox_DeMod_FECO->addItem("Medium");
        ui->comboBox_DeMod_FECO->addItem("Small");
        ui->comboBox_DeMod_FECO->addItem("XLarge");
    }
    qDebug()<<a;
}

void Dialog::on_comboBox_DeMod_FECO_currentIndexChanged(const QString &arg1)
{
    QString a=ui->comboBox_DeMod_FECT->currentText();
    QString b=ui->comboBox_DeMod_FECO->currentText();
    if(a=="UnCoded"){
        while(ui->comboBox_DeMod_FECR->count()>0){
            ui->comboBox_DeMod_FECR->removeItem(0);
        }
        if(b=="None")
        ui->comboBox_DeMod_FECR->addItem("N/A");
   }
    else if(a=="Viterbi"){
        while(ui->comboBox_DeMod_FECR->count()>0){
            ui->comboBox_DeMod_FECR->removeItem(0);
        }
        if(b=="Normal"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("5/6");
            ui->comboBox_DeMod_FECR->addItem("7/8");
        }
        else if(b=="Swap C0/C1"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("5/6");
            ui->comboBox_DeMod_FECR->addItem("7/8");}
        else if(b=="CT"){
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            }

   }
    else if(a=="TCM"){
        while(ui->comboBox_DeMod_FECR->count()>0){
            ui->comboBox_DeMod_FECR->removeItem(0);
        }
        if(b=="Normal"){
            ui->comboBox_DeMod_FECR->addItem("2/3");

        }
   }
    else if(a=="TPC"){
        while(ui->comboBox_DeMod_FECR->count()>0){
            ui->comboBox_DeMod_FECR->removeItem(0);
        }
        if(b=="Advanced"){
            ui->comboBox_DeMod_FECR->addItem("0.453-16K");
            ui->comboBox_DeMod_FECR->addItem("1/2-16K");
            ui->comboBox_DeMod_FECR->addItem("1/2-4K");
            ui->comboBox_DeMod_FECR->addItem("3/4-16K");
            ui->comboBox_DeMod_FECR->addItem("3/4-4K");
            ui->comboBox_DeMod_FECR->addItem("7/8-16K");
            ui->comboBox_DeMod_FECR->addItem("7/8-4K");
            ui->comboBox_DeMod_FECR->addItem("0.922-16K");
            ui->comboBox_DeMod_FECR->addItem("0.950-4K");
        }
        else if(b=="M5 Full"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("7/8");
        }
        else if(b=="M5 Short"){
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("7/8");
        }
        else if(b=="M5 Legacy"){
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("7/8");
        }
        else if(b=="CT"){
            ui->comboBox_DeMod_FECR->addItem("5/16");
            ui->comboBox_DeMod_FECR->addItem("21/44");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            ui->comboBox_DeMod_FECR->addItem("0.95");
        }
   }
    else if(a=="LDPC"){
        while(ui->comboBox_DeMod_FECR->count()>0){
            ui->comboBox_DeMod_FECR->removeItem(0);
        }
        if(b=="256 Block"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("2/3");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("14/17");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            ui->comboBox_DeMod_FECR->addItem("10/11");
            ui->comboBox_DeMod_FECR->addItem("16/17");
        }
        else if(b=="512 Block"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("2/3");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("14/17");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            ui->comboBox_DeMod_FECR->addItem("10/11");
            ui->comboBox_DeMod_FECR->addItem("16/17");
        }
        else if(b=="1K Block"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("2/3");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("14/17");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            ui->comboBox_DeMod_FECR->addItem("10/11");
            ui->comboBox_DeMod_FECR->addItem("16/17");
        }
        else if(b=="2K Block"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("2/3");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("14/17");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            ui->comboBox_DeMod_FECR->addItem("10/11");
            ui->comboBox_DeMod_FECR->addItem("16/17");
        }
        else if(b=="4K Block"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("2/3");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("14/17");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            ui->comboBox_DeMod_FECR->addItem("10/11");
            ui->comboBox_DeMod_FECR->addItem("16/17");
        }
        else if(b=="8K Block"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("2/3");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("14/17");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            ui->comboBox_DeMod_FECR->addItem("10/11");
            ui->comboBox_DeMod_FECR->addItem("16/17");
        }
        else if(b=="16K Block"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("2/3");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("14/17");
            ui->comboBox_DeMod_FECR->addItem("7/8");
            ui->comboBox_DeMod_FECR->addItem("10/11");
            ui->comboBox_DeMod_FECR->addItem("16/17");
        }
    }
    else if(a=="S-Tec"){
        while(ui->comboBox_DeMod_FECR->count()>0){
            ui->comboBox_DeMod_FECR->removeItem(0);}
        if(b=="Large"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("3/5");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("4/5");
            ui->comboBox_DeMod_FECR->addItem("5/6");
            ui->comboBox_DeMod_FECR->addItem("7/8");
        }
        else if(b=="Medium"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("3/5");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("4/5");
            ui->comboBox_DeMod_FECR->addItem("5/6");
            ui->comboBox_DeMod_FECR->addItem("7/8");
        }
        else if(b=="Small"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("3/5");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("4/5");
            ui->comboBox_DeMod_FECR->addItem("5/6");
            ui->comboBox_DeMod_FECR->addItem("7/8");
        }
        else if(b=="XLarge"){
            ui->comboBox_DeMod_FECR->addItem("1/2");
            ui->comboBox_DeMod_FECR->addItem("3/5");
            ui->comboBox_DeMod_FECR->addItem("3/4");
            ui->comboBox_DeMod_FECR->addItem("4/5");
            ui->comboBox_DeMod_FECR->addItem("5/6");
            ui->comboBox_DeMod_FECR->addItem("7/8");
        }
    }
}
